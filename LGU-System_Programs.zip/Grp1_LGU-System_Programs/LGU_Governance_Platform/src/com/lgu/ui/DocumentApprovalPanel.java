package com.lgu.ui;

import com.lgu.dao.FileManager;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class DocumentApprovalPanel extends JPanel {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTable table;
    private DefaultTableModel model;
    private final String[] columns = {"Transaction ID", "Department", "Project", "Amount", "Status"};

    public DocumentApprovalPanel() {
        setLayout(new BorderLayout(0, 20));
        setBackground(new Color(245, 247, 250));
        setBorder(new EmptyBorder(25, 25, 25, 25));

        JLabel header = new JLabel("Budgets for Approval");
        header.setFont(new Font("Segoe UI", Font.BOLD, 22));
        add(header, BorderLayout.NORTH);

        model = new DefaultTableModel(FileManager.getBudgetsByStatus("ALL"), columns);
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel actionBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        
        JButton btnRefresh = new JButton("Refresh");
        btnRefresh.addActionListener(e -> refreshTable());

        JButton btnApprove = new JButton("Sign & APPROVE");
        btnApprove.setBackground(new Color(153, 0, 0));
        btnApprove.setForeground(Color.WHITE);
        
        JButton btnDeny = new JButton("Deny Budget");
        btnDeny.setBackground(new Color(153, 0, 0));
        btnDeny.setForeground(Color.WHITE);
        
        btnApprove.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row != -1) {
                String id = (String) model.getValueAt(row, 0);
                FileManager.updateBudgetStatus(id, "APPROVED");
                JOptionPane.showMessageDialog(this, "Budget " + id + " APPROVED.");
                refreshTable();
            } else {
                JOptionPane.showMessageDialog(this, "Select a budget first.");
            }
        });

        btnDeny.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row != -1) {
                String id = (String) model.getValueAt(row, 0);
                FileManager.updateBudgetStatus(id, "DENIED");
                JOptionPane.showMessageDialog(this, "Budget " + id + " DENIED.");
                refreshTable();
            } else {
                JOptionPane.showMessageDialog(this, "Select a budget first.");
            }
        });

        actionBar.add(btnRefresh);
        actionBar.add(btnDeny);
        actionBar.add(btnApprove);
        add(actionBar, BorderLayout.SOUTH);
    }

    private void refreshTable() {
        model.setDataVector(FileManager.getBudgetsByStatus("ALL"), columns);
    }
}