package com.lgu.ui;

import com.lgu.dao.FileManager;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;

public class PublicCitizenPortal extends JFrame {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField txtBusinessName;
    private JComboBox<String> cbPermitType;
    private JCheckBox chkAffidavit;
    private boolean isFileUploaded = false; // Tracks file upload
    private JButton uploadBtn;

    public PublicCitizenPortal() {
        setTitle("Public Citizen Portal - LGU Digital Governance");
        setSize(650, 450);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Apply for Business Permit", createPermitApplicationPanel());
        tabbedPane.addTab("View Transparency Logs", createTransparencyLogPanel());
        add(tabbedPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton logoutBtn = new JButton("Logout");
        logoutBtn.addActionListener(e -> { this.dispose(); new LoginFrame().setVisible(true); });
        bottomPanel.add(logoutBtn);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    private JPanel createPermitApplicationPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel formPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        formPanel.add(new JLabel("Business Name:"));
        txtBusinessName = new JTextField();
        formPanel.add(txtBusinessName);

        formPanel.add(new JLabel("Permit Type:"));
        cbPermitType = new JComboBox<>(new String[]{"New", "Renewal"});
        formPanel.add(cbPermitType);

        formPanel.add(new JLabel("Upload Document (PDF):"));
        uploadBtn = new JButton("Select File");
        
        // Opens file upload and requires one to be uploaded
        uploadBtn.addActionListener(e -> {
            JFileChooser fc = new JFileChooser();
            if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fc.getSelectedFile();
                uploadBtn.setText("Attached: " + selectedFile.getName());
                isFileUploaded = true;
            }
        });
        formPanel.add(uploadBtn);

        chkAffidavit = new JCheckBox("I certify that all information is true and correct.");
        formPanel.add(chkAffidavit);
        formPanel.add(new JLabel()); 

        JButton submitBtn = new JButton("Submit Application");
        submitBtn.addActionListener(e -> {
            if (txtBusinessName.getText().trim().isEmpty() || !chkAffidavit.isSelected() || !isFileUploaded) {
                JOptionPane.showMessageDialog(this, "You must provide a business name, select a file, and check the affidavit.", "Incomplete", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String newAppId = "APP-" + (int)(Math.random() * 10000);
            FileManager.savePermit(newAppId, txtBusinessName.getText(), cbPermitType.getSelectedItem().toString(), "PENDING");
            
            JOptionPane.showMessageDialog(this, "Application Submitted! ID: " + newAppId, "Success", JOptionPane.INFORMATION_MESSAGE);
            
            txtBusinessName.setText(""); 
            chkAffidavit.setSelected(false);
            isFileUploaded = false;
            uploadBtn.setText("Select File");
        });

        panel.add(new JLabel("<html><h3>Business Permit Application</h3></html>"), BorderLayout.NORTH);
        panel.add(formPanel, BorderLayout.CENTER);
        panel.add(submitBtn, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createTransparencyLogPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.add(new JLabel("<html><h3>Municipal Transparency Ledger</h3></html>"), BorderLayout.NORTH);

        String[] columns = {"Transaction ID", "Category", "Project", "Amount", "Status"};
        DefaultTableModel model = new DefaultTableModel(FileManager.getBudgetsByStatus("APPROVED"), columns);
        panel.add(new JScrollPane(new JTable(model)), BorderLayout.CENTER);

        JButton refreshBtn = new JButton("Refresh Ledger");
        refreshBtn.addActionListener(e -> model.setDataVector(FileManager.getBudgetsByStatus("APPROVED"), columns));
        panel.add(refreshBtn, BorderLayout.SOUTH);
        return panel;
    }
}