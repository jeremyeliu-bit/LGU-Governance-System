package com.lgu.ui;

import javax.swing.*;
import java.awt.*;

public class LGUStaffDashboard extends JFrame {
    private String userRole;

    public LGUStaffDashboard(String role) {
        this.userRole = role;
        setTitle("LGU Internal Dashboard - " + userRole);
        setSize(850, 600);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JTabbedPane tabbedPane = new JTabbedPane();

        if ("STAFF".equals(userRole)) {
            tabbedPane.addTab("Encode Expenses", new BudgetManagementPanel());
        } 
        else if ("ASSESSOR".equals(userRole)) {
            tabbedPane.addTab("Evaluate Applications", new CitizenServicesPanel());
        } 
        else if ("TREASURER".equals(userRole)) {
            tabbedPane.addTab("Sign & Approve Budget", new DocumentApprovalPanel());
        }

        tabbedPane.addTab("VPC Audit Ledger Logs", new AuditTrailPanel()); 
        
        add(tabbedPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton logoutBtn = new JButton("Logout");
        logoutBtn.addActionListener(e -> {
            this.dispose();
            new LoginFrame().setVisible(true);
        });
        bottomPanel.add(logoutBtn);
        add(bottomPanel, BorderLayout.SOUTH);
    }
}