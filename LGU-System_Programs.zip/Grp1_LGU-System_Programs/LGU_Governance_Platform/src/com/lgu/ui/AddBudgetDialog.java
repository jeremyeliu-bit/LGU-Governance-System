package com.lgu.ui;

import com.lgu.dao.FileManager;
import com.lgu.model.BudgetItem;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class AddBudgetDialog extends JDialog {
    private JTextField fundIdField;
    private JComboBox<String> departmentComboBox; 
    private JTextField projectNameField;
    private JTextField amountField;
    private JButton saveButton;
    private JButton cancelButton;
    private DefaultTableModel targetTableModel;

    public AddBudgetDialog(JFrame parent, DefaultTableModel tableModel) {
        super(parent, "Add New Budget Entry", true);
        this.targetTableModel = tableModel;
        initDialog();
    }

    private void initDialog() {
        setSize(400, 350);
        setLocationRelativeTo(getParent());
        setLayout(new BorderLayout());

        JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        formPanel.add(new JLabel("Fund ID (Auto-Generated):"));
        fundIdField = new JTextField("Auto-ID");
        fundIdField.setEnabled(false);
        formPanel.add(fundIdField);

        formPanel.add(new JLabel("Department:"));
        String[] departments = {"Infrastructure", "Public Health", "IT Equipment", "Operations", "Education"};
        departmentComboBox = new JComboBox<>(departments);
        formPanel.add(departmentComboBox);

        formPanel.add(new JLabel("Project Name:"));
        projectNameField = new JTextField();
        formPanel.add(projectNameField);

        formPanel.add(new JLabel("Allocated Amount (PHP):"));
        amountField = new JTextField();
        // Force numbers only
        amountField.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c) && c != '.') {
                    e.consume(); // Blocks letters
                }
            }
        });
        formPanel.add(amountField);

        add(formPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        cancelButton = new JButton("Cancel");
        saveButton = new JButton("Save Item");
        
        saveButton.setForeground(Color.WHITE);
        saveButton.setBackground(new Color(40, 167, 69));

        buttonPanel.add(cancelButton);
        buttonPanel.add(saveButton);
        add(buttonPanel, BorderLayout.SOUTH);

        cancelButton.addActionListener(e -> dispose());

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String department = (String) departmentComboBox.getSelectedItem();
                String projectName = projectNameField.getText().trim();
                String amountStr = amountField.getText().trim();

                if (projectName.isEmpty() || amountStr.isEmpty()) {
                    JOptionPane.showMessageDialog(AddBudgetDialog.this, "Fill out all fields.", "Error", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                try {
                    double amount = Double.parseDouble(amountStr);
                    String txnId = "TXN-" + (int)(Math.random() * 10000);

                    // Creating the item and saving it without the UEBA service check
                    BudgetItem item = new BudgetItem(txnId, department, projectName, amount, "PENDING");
                    item.setId(txnId);
                    
                    FileManager.saveBudgetItem(item);

                    if (targetTableModel != null) {
                        targetTableModel.addRow(new Object[]{txnId, department, projectName, amount, "PENDING"});
                    }
                    dispose();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(AddBudgetDialog.this, "Invalid amount.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }
}