package com.lgu.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import com.lgu.dao.FileManager;

public class BudgetManagementPanel extends JPanel {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private DefaultTableModel model;
    private JTable table;
    private final String[] columns = {"Transaction ID", "Department", "Project", "Amount", "Status"};

    public BudgetManagementPanel() {
        setLayout(new BorderLayout(0, 20));
        setBackground(new Color(245, 247, 250));
        setBorder(new EmptyBorder(25, 25, 25, 25));

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        JLabel header = new JLabel("Municipal Budget & Expenditure Tracking");
        header.setFont(new Font("Segoe UI", Font.BOLD, 22));
        header.setForeground(new Color(33, 37, 41));
        headerPanel.add(header, BorderLayout.WEST);


        JPanel actionButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        actionButtons.setOpaque(false);

        JButton btnRefresh = new JButton("Refresh");
        btnRefresh.setFont(new Font("Segoe UI", Font.BOLD, 13));

        JButton btnAddBudget = new JButton("+ Add New Entry");
        btnAddBudget.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnAddBudget.setBackground(new Color(153, 0, 0)); // Red
        btnAddBudget.setForeground(Color.WHITE); 
        btnAddBudget.setOpaque(true);
        btnAddBudget.setContentAreaFilled(true);
        btnAddBudget.setBorderPainted(false);

        actionButtons.add(btnRefresh);
        actionButtons.add(btnAddBudget);
        headerPanel.add(actionButtons, BorderLayout.EAST);
        
        add(headerPanel, BorderLayout.NORTH);

        // pulls all data from SQL
        model = new DefaultTableModel(FileManager.getBudgetsByStatus("ALL"), columns) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        table = new JTable(model);
        table.setRowHeight(28);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));

        JScrollPane tableScroll = new JScrollPane(table);
        tableScroll.setBorder(BorderFactory.createLineBorder(new Color(220, 224, 230)));

        add(tableScroll, BorderLayout.CENTER);


        
        btnRefresh.addActionListener(e -> {
            model.setDataVector(FileManager.getBudgetsByStatus("ALL"), columns);
        });

        btnAddBudget.addActionListener(e -> {
            LGUStaffDashboard parentFrame = (LGUStaffDashboard) SwingUtilities.getWindowAncestor(this);
            AddBudgetDialog dialog = new AddBudgetDialog(parentFrame, model);
            dialog.setVisible(true);

            model.setDataVector(FileManager.getBudgetsByStatus("ALL"), columns);
        });
    }
}