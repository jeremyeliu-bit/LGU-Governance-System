package com.lgu.ui;

import com.lgu.dao.FileManager;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class CitizenServicesPanel extends JPanel {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTable table;
    private DefaultTableModel model;
    private final String[] columns = {"Application ID", "Business Name", "Permit Type", "Status"};

    public CitizenServicesPanel() {
        setLayout(new BorderLayout(0, 20));
        setBackground(new Color(245, 247, 250));
        setBorder(new EmptyBorder(25, 25, 25, 25));

        JLabel header = new JLabel("Permit Applications Pipeline");
        header.setFont(new Font("Segoe UI", Font.BOLD, 22));
        add(header, BorderLayout.NORTH);

  
        model = new DefaultTableModel(FileManager.getPermitsByStatus("ALL"), columns);
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel actionBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        
        JButton btnRefresh = new JButton("Refresh");
        btnRefresh.addActionListener(e -> refreshTable());

        JButton btnAssess = new JButton("Mark as ASSESSED");
        btnAssess.setBackground(new Color(153, 0, 0)); 
        btnAssess.setForeground(Color.WHITE);
        
        JButton btnDeny = new JButton("Deny Application");
        btnDeny.setBackground(new Color(153, 0, 0));
        btnDeny.setForeground(Color.WHITE);
        
        btnAssess.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row != -1) {
                String id = (String) model.getValueAt(row, 0);
                FileManager.updatePermitStatus(id, "ASSESSED"); 
                JOptionPane.showMessageDialog(this, "Permit " + id + " marked as ASSESSED.");
                refreshTable(); 
            } else {
                JOptionPane.showMessageDialog(this, "Select a permit first.");
            }
        });

        btnDeny.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row != -1) {
                String id = (String) model.getValueAt(row, 0);
                FileManager.updatePermitStatus(id, "DENIED"); 
                JOptionPane.showMessageDialog(this, "Permit " + id + " DENIED.");
                refreshTable(); 
            } else {
                JOptionPane.showMessageDialog(this, "Select a permit first.");
            }
        });

        actionBar.add(btnRefresh);
        actionBar.add(btnDeny);
        actionBar.add(btnAssess);
        add(actionBar, BorderLayout.SOUTH);
    }

    private void refreshTable() {
        model.setDataVector(FileManager.getPermitsByStatus("ALL"), columns);
    }
}