package com.lgu.ui;

import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField usernameField;
    private JPasswordField passwordField;
    private JComboBox<String> roleSelector;

    public LoginFrame() {
        setTitle("LGU Digital Governance System - Login");
        setSize(400, 250);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        panel.add(new JLabel("Username:"));
        usernameField = new JTextField();
        panel.add(usernameField);

        panel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        panel.add(passwordField);

        panel.add(new JLabel("Select Role:"));
        String[] roles = {"CITIZEN", "STAFF", "ASSESSOR", "TREASURER"};
        roleSelector = new JComboBox<>(roles);
        panel.add(roleSelector);

        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(e -> processLogin());
        
        panel.add(new JLabel());
        panel.add(loginButton);

        add(panel);
    }

    private void processLogin() {
        String enteredUser = usernameField.getText();
        String enteredPass = new String(passwordField.getPassword());
        
        if (!"test".equals(enteredUser) || !"test".equals(enteredPass)) {
            JOptionPane.showMessageDialog(this, "Invalid credentials", "Login Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String role = (String) roleSelector.getSelectedItem();
        this.dispose();

        if ("CITIZEN".equals(role)) {
            SwingUtilities.invokeLater(() -> new PublicCitizenPortal().setVisible(true));
        } else {
            SwingUtilities.invokeLater(() -> new LGUStaffDashboard(role).setVisible(true));
        }
    }
}