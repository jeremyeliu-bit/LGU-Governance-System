package com.lgu.ui;

import com.lgu.dao.FileManager;
import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class AuditTrailPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    
    // The exact 4 columns requested
    private final String[] columns = {"Audit Entry ID", "User / Role", "Action", "Time"};

    public AuditTrailPanel() {
        setLayout(new BorderLayout(0, 20));
        setBackground(new Color(245, 247, 250));
        setBorder(new EmptyBorder(25, 25, 25, 25));

        JLabel header = new JLabel("VPC Shield Audit Ledger");
        header.setFont(new Font("Segoe UI", Font.BOLD, 22));
        add(header, BorderLayout.NORTH);

        model = new DefaultTableModel(FileManager.getAuditLogs(), columns) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        table = new JTable(model);
        table.setRowHeight(28);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));

        JScrollPane tableScroll = new JScrollPane(table);
        tableScroll.setBorder(BorderFactory.createLineBorder(new Color(220, 224, 230)));
        add(tableScroll, BorderLayout.CENTER);

        // Created a bottom panel to hold multiple buttons neatly
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.setBackground(new Color(245, 247, 250));

        JButton btnExport = new JButton("EXPORT");
        btnExport.setBackground(new Color(40, 167, 69)); // Green for export action
        btnExport.setForeground(Color.WHITE);
        btnExport.addActionListener(e -> exportToCSV());

        JButton btnRefresh = new JButton("Refresh Logs");
        btnRefresh.setBackground(new Color(153, 0, 0)); 
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.addActionListener(e -> model.setDataVector(FileManager.getAuditLogs(), columns));

        bottomPanel.add(btnExport);
        bottomPanel.add(btnRefresh);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void exportToCSV() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save Audit Logs as CSV");
        fileChooser.setSelectedFile(new File("VPC_Audit_Ledger.csv"));
        
        int userSelection = fileChooser.showSaveDialog(this);
        
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            
            // Ensure the file ends with .csv
            if (!fileToSave.getName().toLowerCase().endsWith(".csv")) {
                fileToSave = new File(fileToSave.getParentFile(), fileToSave.getName() + ".csv");
            }

            try (FileWriter fw = new FileWriter(fileToSave)) {
                // Write the CSV Column Headers
                for (int i = 0; i < model.getColumnCount(); i++) {
                    fw.write(model.getColumnName(i) + (i == model.getColumnCount() - 1 ? "" : ","));
                }
                fw.write("\n");

                // Write the Table Data Rows
                for (int i = 0; i < model.getRowCount(); i++) {
                    for (int j = 0; j < model.getColumnCount(); j++) {
                        String cellData = model.getValueAt(i, j) != null ? model.getValueAt(i, j).toString() : "";
                        
                        // Encapsulate in quotes and escape internal quotes to prevent CSV breaking
                        cellData = "\"" + cellData.replace("\"", "\"\"") + "\"";
                        
                        fw.write(cellData + (j == model.getColumnCount() - 1 ? "" : ","));
                    }
                    fw.write("\n");
                }
                
                JOptionPane.showMessageDialog(this, "Export successful!\nSaved to: " + fileToSave.getAbsolutePath(), "Export Complete", JOptionPane.INFORMATION_MESSAGE);
                
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Error saving CSV file: " + ex.getMessage(), "Export Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}