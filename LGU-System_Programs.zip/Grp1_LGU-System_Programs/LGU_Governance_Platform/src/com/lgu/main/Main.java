package com.lgu.main;

import com.lgu.ui.LoginFrame;
import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            applyCustomTheme();
            LoginFrame loginScreen = new LoginFrame();
            loginScreen.setVisible(true);
        });
    }

    private static void applyCustomTheme() {

        Color cardinalRed = new Color(153, 0, 0);
        Color gold = new Color(255, 204, 51);
        Color lightGray = new Color(245, 245, 245);
        Color darkText = new Color(30, 30, 30);


        UIManager.put("Panel.background", lightGray);
        UIManager.put("OptionPane.background", lightGray);
        
        UIManager.put("Button.background", cardinalRed);
        UIManager.put("Button.foreground", Color.WHITE);
        UIManager.put("Button.font", new Font("SansSerif", Font.BOLD, 12));
        UIManager.put("Button.setOpaque", true);
        
        UIManager.put("Label.foreground", darkText);
        UIManager.put("Label.font", new Font("SansSerif", Font.PLAIN, 13));
        
        UIManager.put("TabbedPane.background", lightGray);
        UIManager.put("TabbedPane.selected", gold);
        UIManager.put("TabbedPane.contentAreaColor", lightGray);
        
        UIManager.put("Table.selectionBackground", cardinalRed);
        UIManager.put("Table.selectionForeground", Color.WHITE);
        UIManager.put("Table.background", Color.WHITE);
        
        UIManager.put("ComboBox.background", Color.WHITE);
        UIManager.put("TextField.background", Color.WHITE);
    }
}