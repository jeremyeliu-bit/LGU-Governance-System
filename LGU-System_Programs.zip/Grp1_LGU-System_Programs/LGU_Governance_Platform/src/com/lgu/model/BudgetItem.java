package com.lgu.model;

public class BudgetItem {
    private String id;
    private String fundId;
    private String department;
    private String projectName;
    private double amount;
    private double allocatedAmount;
    private String status;
    private String description;

    public BudgetItem() {
    }

    public BudgetItem(String id, String projectName, double amount) {
        this.id = id;
        this.projectName = projectName;
        this.amount = amount;
        this.allocatedAmount = amount;
    }

    // constructors
    public BudgetItem(String fundId, String department, String projectName, double allocatedAmount, String status) {
        this.fundId = fundId;
        this.department = department;
        this.projectName = projectName;
        this.allocatedAmount = allocatedAmount;
        this.amount = allocatedAmount;
        this.status = status;
    }

    // Overloaded constructor if strings are passed from dialog fields
    public BudgetItem(String fundId, String department, String projectName, String allocatedAmountStr, String status) {
        this.fundId = fundId;
        this.department = department;
        this.projectName = projectName;
        try {
            this.allocatedAmount = Double.parseDouble(allocatedAmountStr);
            this.amount = this.allocatedAmount;
        } catch (NumberFormatException e) {
            this.allocatedAmount = 0.0;
            this.amount = 0.0;
        }
        this.status = status;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getFundId() { return fundId; }
    public void setFundId(String fundId) { this.fundId = fundId; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getProjectName() { return projectName; }
    public void setProjectName(String projectName) { this.projectName = projectName; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public double getAllocatedAmount() { return allocatedAmount; }
    public void setAllocatedAmount(double allocatedAmount) { this.allocatedAmount = allocatedAmount; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}