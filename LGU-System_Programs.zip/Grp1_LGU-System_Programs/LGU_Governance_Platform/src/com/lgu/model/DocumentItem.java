package com.lgu.model;

public class DocumentItem {
    private String id;
    private String documentName;
    private String filePath;
    private String extractedData;

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public void setExtractedData(String extractedData) {
        this.extractedData = extractedData;
    }
}