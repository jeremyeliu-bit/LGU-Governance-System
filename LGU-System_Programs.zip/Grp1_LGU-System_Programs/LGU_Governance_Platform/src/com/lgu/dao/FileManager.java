package com.lgu.dao;

import com.lgu.model.BudgetItem;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FileManager {
    private static final String URL = "jdbc:mysql://localhost:3306/lgu_system";
    private static final String USER = "root"; 
    private static final String PASS = "Aug2025162189"; // CHANGE TO YOUR PASSWORD

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    public static void savePermit(String id, String name, String type, String status) {
        String sql = "INSERT INTO business_permits (application_id, business_name, permit_type, status) VALUES (?, ?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, id); 
            pstmt.setString(2, name); 
            pstmt.setString(3, type); 
            pstmt.setString(4, status);
            pstmt.executeUpdate();
        } catch (SQLException e) { 
            e.printStackTrace(); 
        }
    }

    public static Object[][] getPermitsByStatus(String status) {
        List<Object[]> list = new ArrayList<>();
        String sql = status.equals("ALL") ? "SELECT * FROM business_permits" : "SELECT * FROM business_permits WHERE status = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            if (!status.equals("ALL")) {
                pstmt.setString(1, status);
            }
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                list.add(new Object[]{
                    rs.getString("application_id"), 
                    rs.getString("business_name"), 
                    rs.getString("permit_type"), 
                    rs.getString("status")
                });
            }
        } catch (SQLException e) { 
            e.printStackTrace(); 
        }
        return list.toArray(new Object[0][]);
    }

    public static void updatePermitStatus(String id, String status) {
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement("UPDATE business_permits SET status = ? WHERE application_id = ?")) {
            pstmt.setString(1, status); 
            pstmt.setString(2, id); 
            pstmt.executeUpdate();
        } catch (SQLException e) { 
            e.printStackTrace(); 
        }
    }

    public static void saveBudgetItem(BudgetItem item) {
        String sql = "INSERT INTO budget_ledger (transaction_id, department, project_name, amount, status) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, item.getFundId()); 
            pstmt.setString(2, item.getDepartment());
            pstmt.setString(3, item.getProjectName()); 
            pstmt.setDouble(4, item.getAmount()); 
            pstmt.setString(5, item.getStatus());
            pstmt.executeUpdate();
        } catch (SQLException e) { 
            e.printStackTrace(); 
        }
    }

    public static Object[][] getBudgetsByStatus(String status) {
        List<Object[]> list = new ArrayList<>();
        String sql = status.equals("ALL") ? "SELECT * FROM budget_ledger" : "SELECT * FROM budget_ledger WHERE status = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            if (!status.equals("ALL")) {
                pstmt.setString(1, status);
            }
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                list.add(new Object[]{
                    rs.getString("transaction_id"), 
                    rs.getString("department"), 
                    rs.getString("project_name"), 
                    rs.getDouble("amount"), 
                    rs.getString("status")
                });
            }
        } catch (SQLException e) { 
            e.printStackTrace(); 
        }
        return list.toArray(new Object[0][]);
    }

    public static void updateBudgetStatus(String id, String status) {
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement("UPDATE budget_ledger SET status = ? WHERE transaction_id = ?")) {
            pstmt.setString(1, status); 
            pstmt.setString(2, id); 
            pstmt.executeUpdate();
        } catch (SQLException e) { 
            e.printStackTrace(); 
        }
    }

    // Fetches the role column alongside ID, action, and timestamp
    public static Object[][] getAuditLogs() {
        List<Object[]> list = new ArrayList<>();
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery("SELECT audit_id, user_role, action_event, timestamp FROM vpc_audit_ledger ORDER BY timestamp DESC")) {
            while (rs.next()) {
                list.add(new Object[]{
                    rs.getString("audit_id"), 
                    rs.getString("user_role"), 
                    rs.getString("action_event"), 
                    rs.getString("timestamp")
                });
            }
        } catch (SQLException e) { 
            e.printStackTrace(); 
        }
        return list.toArray(new Object[0][]);
    }
}