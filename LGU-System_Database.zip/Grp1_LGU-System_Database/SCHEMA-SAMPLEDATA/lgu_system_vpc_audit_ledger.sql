-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: lgu_system
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `vpc_audit_ledger`
--

DROP TABLE IF EXISTS `vpc_audit_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vpc_audit_ledger` (
  `audit_id` int NOT NULL AUTO_INCREMENT,
  `user_role` varchar(50) DEFAULT 'SYSTEM',
  `action_event` varchar(255) DEFAULT NULL,
  `timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`audit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vpc_audit_ledger`
--

LOCK TABLES `vpc_audit_ledger` WRITE;
/*!40000 ALTER TABLE `vpc_audit_ledger` DISABLE KEYS */;
INSERT INTO `vpc_audit_ledger` VALUES (1,'STAFF','Encoded Budget Expense: TXN-9157','2026-09-29 22:10:52'),(2,'CITIZEN','Submitted Business Permit: APP-9228','2026-10-06 23:19:05'),(3,'CITIZEN','Submitted Business Permit: APP-2075','2026-10-06 23:19:14'),(4,'STAFF','Encoded Budget Expense: TXN-2453','2026-10-06 23:19:30'),(5,'STAFF','Encoded Budget Expense: TXN-9037','2026-10-06 23:19:36'),(6,'ASSESSOR','Updated Permit APP-9228 to DENIED','2026-10-06 23:19:47'),(7,'ASSESSOR','Updated Permit APP-2075 to ASSESSED','2026-10-06 23:19:50'),(8,'TREASURER','Updated Budget TXN-2453 to APPROVED','2026-10-06 23:20:00'),(9,'TREASURER','Updated Budget TXN-9037 to DENIED','2026-10-06 23:20:02');
/*!40000 ALTER TABLE `vpc_audit_ledger` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-06 23:21:59
