CREATE DATABASE lgu_system;
USE lgu_system;



-- 1. Permits Table (Citizen to Assessor)
CREATE TABLE business_permits (
    application_id VARCHAR(50) PRIMARY KEY,
    business_name VARCHAR(100),
    permit_type VARCHAR(50),
    status VARCHAR(50),
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 2. Budget Table (Staff to Treasurer)
CREATE TABLE budget_ledger (
    transaction_id VARCHAR(50) PRIMARY KEY,
    department VARCHAR(100),
    project_name VARCHAR(255),
    amount DECIMAL(15,2),
    status VARCHAR(50),
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 3. VPC Audit Ledger (Seen by all users)
CREATE TABLE vpc_audit_ledger (
    audit_id INT AUTO_INCREMENT PRIMARY KEY,
    user_role VARCHAR(50) DEFAULT 'SYSTEM',
    action_event VARCHAR(255),
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 4. Triggers (Automated Audit Logging)
DELIMITER //

CREATE TRIGGER after_permit_insert 
AFTER INSERT ON business_permits 
FOR EACH ROW
BEGIN 
    INSERT INTO vpc_audit_ledger (user_role, action_event) 
    VALUES ('CITIZEN', CONCAT('Submitted Business Permit: ', NEW.application_id)); 
END;//

CREATE TRIGGER after_permit_update 
AFTER UPDATE ON business_permits 
FOR EACH ROW
BEGIN 
    INSERT INTO vpc_audit_ledger (user_role, action_event) 
    VALUES ('ASSESSOR', CONCAT('Updated Permit ', NEW.application_id, ' to ', NEW.status)); 
END;//

CREATE TRIGGER after_budget_insert 
AFTER INSERT ON budget_ledger 
FOR EACH ROW
BEGIN 
    INSERT INTO vpc_audit_ledger (user_role, action_event) 
    VALUES ('STAFF', CONCAT('Encoded Budget Expense: ', NEW.transaction_id)); 
END;//

CREATE TRIGGER after_budget_update 
AFTER UPDATE ON budget_ledger 
FOR EACH ROW
BEGIN 
    INSERT INTO vpc_audit_ledger (user_role, action_event) 
    VALUES ('TREASURER', CONCAT('Updated Budget ', NEW.transaction_id, ' to ', NEW.status)); 
END;//

DELIMITER ;

SELECT * FROM business_permits